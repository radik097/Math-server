function rav(){
var y = Number(document.getElementById("y").value);
var k = Number(document.getElementById("k").value);
var x = Number(document.getElementById("x").value);
var pow = Number(document.getElementById("pow").value);
var b = Number(document.getElementById("b").value);

}

